# Kisah Sukses Final AI Hebat

Render-ready package. Push files to repo root.

## Render + Groq setup (added automatically)
1. Copy `.env.example` to `.env` and set `GROQ_API_KEY`.
2. `npm install`
3. `npm start`

Health: GET /healthz

