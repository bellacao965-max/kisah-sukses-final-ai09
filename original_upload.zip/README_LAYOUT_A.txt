Layout A applied and AI endpoints ensured. Update GROQ_API_KEY in Render environment variables and redeploy.

## Render + Groq setup (added automatically)
1. Copy `.env.example` to `.env` and set `GROQ_API_KEY`.
2. `npm install`
3. `npm start`

Health: GET /healthz

